package ir.hesabyar.moamelat

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.DecimalFormat

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("hesabyar", MODE_PRIVATE) }
    private val deals = mutableListOf<JSONObject>()
    private lateinit var page: LinearLayout
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun money(n: Double): String = DecimalFormat("#,##0.##").format(n)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF245A48.toInt()
        loadDeals()
        renderHome()
    }

    private fun basePage(title: String): LinearLayout {
        val scroll = ScrollView(this)
        page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(28))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            textDirection = View.TEXT_DIRECTION_RTL
        }
        scroll.addView(page)
        setContentView(scroll)
        label(page, title, 25, 0xFF245A48.toInt(), true)
        return page
    }

    private fun renderHome() {
        basePage("حساب‌یار معاملات")
        label(page, "مدیریت معاملات، سرمایه شرکا و سود و زیان", 15)
        button(page, "+ ثبت معامله جدید") { renderNewDeal() }
        button(page, "پشتیبان‌گیری از اطلاعات") { exportBackup() }
        label(page, "معاملات ثبت‌شده: ${deals.size}", 18, 0xFF245A48.toInt(), true)
        if (deals.isEmpty()) label(page, "هنوز معامله‌ای ثبت نشده است. برای شروع، «ثبت معامله جدید» را بزنید.", 15)
        deals.asReversed().forEach { deal ->
            val box = card(page)
            label(box, deal.optString("name", "معامله بدون نام"), 18, 0xFF245A48.toInt(), true)
            label(box, "سود/زیان نهایی: ${money(deal.optDouble("profit"))} تومان", 15)
            label(box, "تاریخ: ${deal.optString("date", "ثبت نشده")}", 13, 0xFF666666.toInt())
            button(box, "مشاهده گزارش") { showReport(deal) }
            button(box, "حذف معامله") {
                AlertDialog.Builder(this).setMessage("این معامله حذف شود؟").setNegativeButton("انصراف", null)
                    .setPositiveButton("حذف") { _, _ -> deals.remove(deal); saveDeals(); renderHome() }.show()
            }
        }
        label(page, "اطلاعات فقط روی همین گوشی ذخیره می‌شود. برای نگهداری امن، مرتباً پشتیبان بگیرید.", 12, 0xFF777777.toInt())
    }

    private fun renderNewDeal() {
        basePage("ثبت معامله جدید")
        val name = input(page, "نام معامله یا پروژه")
        val date = input(page, "تاریخ شمسی (مثلاً ۱۴۰۵/۰۸/۰۵)")
        val buy = input(page, "مبلغ خرید (تومان)", "0", true)
        val sell = input(page, "مبلغ فروش (تومان)", "0", true)
        val costs = input(page, "مجموع هزینه‌ها (تومان)", "0", true)
        label(page, "شرکا را هر کدام در یک خط وارد کنید؛ قالب هر خط: نام، مبلغ سرمایه", 14, 0xFF245A48.toInt(), true)
        val partners = EditText(this).apply {
            hint = "مثال:\nعلی، 500000000\nرضا، 300000000"
            minLines = 4; gravity = Gravity.TOP or Gravity.RIGHT
            setPadding(dp(12), dp(12), dp(12), dp(12))
            textDirection = View.TEXT_DIRECTION_RTL
            background = fieldBackground()
        }
        page.addView(partners, match().apply { topMargin = dp(6); bottomMargin = dp(12) })
        button(page, "محاسبه و ذخیره معامله") {
            val buyValue = parseMoney(buy.text.toString())
            val sellValue = parseMoney(sell.text.toString())
            val costValue = parseMoney(costs.text.toString())
            if (name.text.toString().trim().isEmpty()) { toast("نام معامله را وارد کنید."); return@button }
            val partnerArray = JSONArray()
            var totalCapital = 0.0
            partners.text.toString().lines().filter { it.isNotBlank() }.forEach { line ->
                val parts = line.split("،", ",", "؛", ";")
                if (parts.size >= 2) {
                    val amount = parseMoney(parts.drop(1).joinToString(""))
                    if (parts[0].trim().isNotEmpty() && amount > 0) {
                        partnerArray.put(JSONObject().put("name", parts[0].trim()).put("capital", amount))
                        totalCapital += amount
                    }
                }
            }
            if (partnerArray.length() == 0) { toast("حداقل یک شریک با مبلغ سرمایه وارد کنید."); return@button }
            val profit = sellValue - buyValue - costValue
            val deal = JSONObject().put("id", System.currentTimeMillis()).put("name", name.text.toString().trim())
                .put("date", date.text.toString().trim().ifEmpty { "ثبت نشده" })
                .put("buy", buyValue).put("sell", sellValue).put("costs", costValue)
                .put("profit", profit).put("totalCapital", totalCapital).put("partners", partnerArray)
            deals.add(deal); saveDeals()
            AlertDialog.Builder(this).setTitle("معامله ذخیره شد")
                .setMessage("سود/زیان پس از کسر هزینه‌ها: ${money(profit)} تومان\nاطلاعات روی گوشی ذخیره شد.")
                .setPositiveButton("مشاهده گزارش") { _, _ -> showReport(deal) }
                .setNegativeButton("بازگشت به فهرست") { _, _ -> renderHome() }.show()
        }
        button(page, "بازگشت") { renderHome() }
    }

    private fun showReport(deal: JSONObject) {
        basePage("گزارش معامله")
        label(page, deal.optString("name"), 22, 0xFF245A48.toInt(), true)
        label(page, "تاریخ: ${deal.optString("date")}", 14)
        label(page, "مبلغ خرید: ${money(deal.optDouble("buy"))} تومان", 16)
        label(page, "مبلغ فروش: ${money(deal.optDouble("sell"))} تومان", 16)
        label(page, "مجموع هزینه‌ها: ${money(deal.optDouble("costs"))} تومان", 16)
        val profit = deal.optDouble("profit")
        label(page, "${if (profit >= 0) "سود" else "زیان"} نهایی: ${money(kotlin.math.abs(profit))} تومان", 20, 0xFF245A48.toInt(), true)
        label(page, "سهم هر شریک بر اساس نسبت سرمایه اولیه محاسبه شده است:", 14)
        val arr = deal.optJSONArray("partners") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val p = arr.getJSONObject(i)
            val ratio = if (deal.optDouble("totalCapital") > 0) p.optDouble("capital") / deal.optDouble("totalCapital") else 0.0
            val box = card(page)
            label(box, p.optString("name"), 17, 0xFF245A48.toInt(), true)
            label(box, "سرمایه: ${money(p.optDouble("capital"))} تومان", 14)
            label(box, "درصد سهم: ${money(ratio * 100)}٪", 14)
            label(box, "سهم از سود/زیان: ${money(profit * ratio)} تومان", 15)
        }
        label(page, "توجه: این گزارش، سود/زیان معامله را بر اساس خرید، فروش و مجموع هزینه واردشده محاسبه می‌کند؛ تقسیم هزینه‌ها به تفکیک هر شریک در این نسخه انجام نمی‌شود.", 12, 0xFF777777.toInt())
        button(page, "بازگشت به فهرست") { renderHome() }
    }

    private fun exportBackup() {
        val backup = JSONArray()
        deals.forEach { backup.put(it) }
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "application/json"
            putExtra(Intent.EXTRA_SUBJECT, "پشتیبان حساب‌یار معاملات")
            putExtra(Intent.EXTRA_TEXT, backup.toString(2))
        }
        startActivity(Intent.createChooser(send, "ارسال یا ذخیره پشتیبان"))
    }

    private fun loadDeals() {
        try {
            val arr = JSONArray(prefs.getString("deals", "[]"))
            for (i in 0 until arr.length()) deals.add(arr.getJSONObject(i))
        } catch (_: Exception) { }
    }
    private fun saveDeals() { prefs.edit().putString("deals", JSONArray(deals).toString()).apply() }
    private fun parseMoney(s: String): Double = s.replace(",", "").replace("٬", "").replace("٫", ".")
        .replace("۰", "0").replace("۱", "1").replace("۲", "2").replace("۳", "3").replace("۴", "4")
        .replace("۵", "5").replace("۶", "6").replace("۷", "7").replace("۸", "8").replace("۹", "9")
        .replace("٠", "0").replace("١", "1").replace("٢", "2").replace("٣", "3").replace("٤", "4")
        .replace("٥", "5").replace("٦", "6").replace("٧", "7").replace("٨", "8").replace("٩", "9").trim().toDoubleOrNull() ?: 0.0

    private fun input(parent: LinearLayout, hintText: String, default: String = "", numeric: Boolean = false): EditText {
        val e = EditText(this).apply {
            hint = hintText; setText(default); textSize = 15f
            gravity = Gravity.RIGHT; textDirection = View.TEXT_DIRECTION_RTL
            setPadding(dp(12), dp(8), dp(12), dp(8)); background = fieldBackground()
            if (numeric) inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        parent.addView(e, match().apply { topMargin = dp(5); bottomMargin = dp(8) })
        return e
    }
    private fun label(parent: LinearLayout, textValue: String, size: Int, color: Int = 0xFF333333.toInt(), bold: Boolean = false) {
        parent.addView(TextView(this).apply {
            text = textValue; textSize = size.toFloat(); gravity = Gravity.RIGHT
            textDirection = View.TEXT_DIRECTION_RTL; setTextColor(color)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, dp(5), 0, dp(5))
        }, match())
    }
    private fun button(parent: LinearLayout, textValue: String, action: () -> Unit) {
        val b = Button(this).apply { text = textValue; isAllCaps = false; setOnClickListener { action() } }
        parent.addView(b, match().apply { topMargin = dp(5); bottomMargin = dp(7) })
    }
    private fun card(parent: LinearLayout): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(10))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0xFFF4F7F5.toInt()); cornerRadius = dp(12).toFloat(); setStroke(dp(1), 0xFFDCE7E0.toInt())
            }
        }
        parent.addView(box, match().apply { topMargin = dp(8); bottomMargin = dp(8) })
        return box
    }
    private fun fieldBackground() = android.graphics.drawable.GradientDrawable().apply {
        setColor(0xFFFFFFFF.toInt()); cornerRadius = dp(8).toFloat(); setStroke(dp(1), 0xFFCBD8D0.toInt())
    }
    private fun match() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
